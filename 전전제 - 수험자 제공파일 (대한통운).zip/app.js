window.onload = function(){
    $(".menu > li > ul").hide();
    $(".pop").hide();
    $(".aggro").hide();
    $(".menu").hover(function(){
        $(".menu > li > ul").slideDown('fast');
        $(".aggro").slideDown('fast');
    }, function(){
        $(".menu > li > ul").slideUp('fast');
        $(".aggro").slideUp('fast');
    });
    $(".b_section > img").css({ "top": "300px" });
    $(".b_section > img").eq(0).css({ "top": 0 });
    let idx = 0;
    setInterval(() => {
        let next = (idx + 1) % 3;
        $(".b_section > img").eq(next).css({ "top": "300px" }).stop().animate({ "top": 0 }, 800);
        $(".b_section > img").eq(idx).stop().animate({ "top": "-300px" }, 800);
        idx = next;
    }, 3000);
}

function openPop(){
    $(".pop").show('slow');
}
function closePop(){
    $(".pop").hide('fast');
}